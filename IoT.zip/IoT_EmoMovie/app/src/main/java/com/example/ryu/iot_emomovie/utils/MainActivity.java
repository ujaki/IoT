package com.example.ryu.iot_emomovie.utils;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.ryu.iot_emomovie.R;
import com.example.ryu.iot_emomovie.utils.utils.ApplicationPreference;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.kt.gigaiot_sdk.DeviceApi;
import com.kt.gigaiot_sdk.GigaIotOAuth;
import com.kt.gigaiot_sdk.MemberApi;
import com.kt.gigaiot_sdk.TagStrmApi;
import com.kt.gigaiot_sdk.data.AccessToken;
import com.kt.gigaiot_sdk.data.Device;
import com.kt.gigaiot_sdk.data.DeviceApiResponse;
import com.kt.gigaiot_sdk.data.GiGaIotOAuthResponse;
import com.kt.gigaiot_sdk.data.Member;
import com.kt.gigaiot_sdk.data.MemberApiResponse;
import com.kt.gigaiot_sdk.network.ApiConstants;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName(); //디버그용 태그 이름
    private GoogleCloudMessaging gcm;           //push 알림 - gcm

    private String user_id = "";
    private String user_pwd = "";
    private String app_id = "";
    private String app_secret = "";

    private AccessToken accessToken = null;
    private Member member = null;

    private String memberSeq = "";          //사용자 일련번호

    private GiGaIotOAuthResponse oAuthResponse = null;
    private TagStrmApi tagStrmApi = null;
    private DeviceApi deviceApi = null;
    private DeviceApiResponse deviceApiResponse = null;
    // private MemberApiResponse memberApiResponse = null;
    private MemberApi memberApi = null;

    //String access_token= "";
    // private VideoView videoView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ApplicationPreference.init(this);

        user_id = getString(R.string.user_id);
        user_pwd = getString(R.string.user_pwd);
        app_id = getString(R.string.app_id);
        app_secret = getString(R.string.app_secret);

        new GiGaIotOAuthTask().execute();

    }
    /*
        @Override
        protected void onStart() {
            super.onStart();

            try{
                memberApi = new MemberApi(access_token);        //Member API
                tagStrmApi = new TagStrmApi(access_token);      //Tag Stream API
                deviceApi = new DeviceApi(access_token);        //Device API
                Log.d("Instances Task " , "is done");



               // Log.d("Member Info : " , memberApiResponse.getMessage());
            }catch (Exception e){
                e.printStackTrace();
            }
            new GiGaIotOAuthTask().execute();
            //memberApiResponse = memberApi.getMemberInfo(memberSeq);

            //deviceApiResponse = deviceApi.;
            //ArrayList<Device> devices_list = deviceApiResponse.getDevices();

               /* for (Device lists : devices_list){
                    Log.d("Device list : ", lists.getDevNm());
                }

        }
    */
    private class GiGaIotOAuthTask extends AsyncTask<Void, Void, GiGaIotOAuthResponse>{
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            JSONObject jsonObject = new JSONObject();

            progressDialog = ProgressDialog.show(MainActivity.this, "", "잠시만 기다려주세요", true, false);
        }

        @Override
        protected GiGaIotOAuthResponse doInBackground(Void... params) {
            GigaIotOAuth gigaIotOAuth = new GigaIotOAuth(app_id, app_secret);
            GiGaIotOAuthResponse response = gigaIotOAuth.loginWithPassword("ujakifox2", "koreatech12!@");
            return response;
        }

        @Override
        protected void onPostExecute(GiGaIotOAuthResponse response) {
            //super.onPostExecute(response);
            if(progressDialog != null && progressDialog.isShowing()){
                progressDialog.dismiss();
                progressDialog = null;


            }

            if(response != null && response.getResponseCode().equals(ApiConstants.CODE_OK)){
                ApplicationPreference.getInstance().setPrefAccountId(user_id);
                ApplicationPreference.getInstance().setPrefAccessToken(response.getAccessToken());
                ApplicationPreference.getInstance().setPrefAccountMbrSeq(response.getMbrSeq());

                Log.d(TAG, response.getMessage());
                Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_LONG).show();

                new GetMemberTask().execute();


            }else{
                Toast.makeText(getApplicationContext(), "로그인 실패" + response.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private class GetMemberTask extends AsyncTask<Void, Void, MemberApiResponse>{

        @Override
        protected MemberApiResponse doInBackground(Void... params) {
            MemberApi memberApi = new MemberApi(ApplicationPreference.getInstance().getPrefAccessToken());
            MemberApiResponse response = memberApi.getMemberInfo(ApplicationPreference.getInstance().getPrefAccountMbrSeq());


            return response;
        }

        @Override
        protected void onPostExecute(MemberApiResponse response) {

            Member member = response.getMember();
            Log.d(TAG, "Email : " + member.getEmail());
            Log.d(TAG, "User Name : "+ member.getUserNm());
            new GetDeviceListTask().execute();
            //Log.d(TAG, );
            //Log.d(TAG, );
            //Log.d(TAG, );
        }
    }

    private class GetDeviceListTask extends AsyncTask<Void, Void, DeviceApiResponse>{

        @Override
        protected DeviceApiResponse doInBackground(Void... params) {
            DeviceApi deviceApi = new DeviceApi(ApplicationPreference.getInstance().getPrefAccessToken());
            DeviceApiResponse response = deviceApi.getDeviceList(ApplicationPreference.getInstance().getPrefAccountMbrSeq(), 1, 10);
            return response;
        }

        @Override
        protected void onPostExecute(DeviceApiResponse response) {
            Log.d(TAG, "Device Total : " + response.getTotal());
            ArrayList<Device> list = response.getDevices();

            for(Device device : list){
                //Log.d(TAG, "Device Id : " + device.getDevUUID());
                Log.d(TAG, "Device Pwd : " + device.getDevPwd());
                Log.d(TAG, "spotDevId : " +device.getSpotDevId());
                Log.d(TAG, "spotDevSeq : " +device.getSpotDevSeq());
                Log.d(TAG, "Model Name : " +device.getDevModelNm());
                Log.d(TAG, "Device Name : " + device.getDevNm());
                Log.d(TAG, "svcTgtSeq : " +device.getSvcTgtSeq());

                /*
                for(int i = 0; i < tagLists.; i++){
                    Log.d(TAG, "Tag Stream ID : " +tagLists.get(i).getTagStrmId());
                    Log.d(TAG, "------------------------------------------");
                }
                */

            }
        }
    }

    /*
    private class GetTagStrmListTask extends AsyncTask<Void, Void, Void>{

        @Override
        protected DeviceApiResponse doInBackground(Void... params) {
            DeviceApi deviceApi = new DeviceApi()
            return null;
        }
    }
*/

}
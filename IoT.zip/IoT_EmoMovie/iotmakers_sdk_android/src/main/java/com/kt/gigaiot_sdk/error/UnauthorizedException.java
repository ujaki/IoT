package com.kt.gigaiot_sdk.error;

/**
 * Created by NP1014425901 on 2015-08-18.
 */
public class UnauthorizedException extends GiGaIotException {

    public UnauthorizedException(String detailMessage) {
        super(detailMessage);
    }
}

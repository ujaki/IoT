package com.kt.gigaiot_sdk.data;

import com.google.gson.annotations.SerializedName;

/**
 * Created by ceoko on 15. 6. 12..
 */
public class AccessToken {

    @SerializedName("error")
    private String error;

    @SerializedName("error_description")
    private String error_description;

    @SerializedName("access_token")
    private String access_token;

    @SerializedName("token_type")
    private String token_type;

    @SerializedName("expires_in")
    private String expires_in;

    @SerializedName("scope")
    private String scope;

    @SerializedName("svc_tgt_seq")
    private String svc_tgt_seq;

    @SerializedName("platform")
    private String platform;

    @SerializedName("svc_cd")
    private String svc_cd;

    @SerializedName("mbr_seq")
    private String mbr_seq;

    @SerializedName("company")
    private String company;

    @SerializedName("dstr_cd")
    private String dstr_cd;

    @SerializedName("theme_cd")
    private String theme_cd;

    @SerializedName("mbr_id")
    private String mbr_id;

    @SerializedName("jti")
    private String jti;

    public String getError() {
        return error;
    }

    public String getError_description() {
        return error_description;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setError(String error) {
        this.error = error;
    }

    public void setError_description(String error_description) {
        this.error_description = error_description;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public void setToken_type(String token_type) {
        this.token_type = token_type;
    }

    public void setExpires_in(String expires_in) {
        this.expires_in = expires_in;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public void setSvc_tgt_seq(String svc_tgt_seq) {
        this.svc_tgt_seq = svc_tgt_seq;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public void setSvc_cd(String svc_cd) {
        this.svc_cd = svc_cd;
    }

    public void setMbr_seq(String mbr_seq) {
        this.mbr_seq = mbr_seq;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void setDstr_cd(String dstr_cd) {
        this.dstr_cd = dstr_cd;
    }

    public void setTheme_cd(String theme_cd) {
        this.theme_cd = theme_cd;
    }

    public void setMbr_id(String mbr_id) {
        this.mbr_id = mbr_id;
    }

    public void setJti(String jti) {
        this.jti = jti;
    }

    public String getToken_type() {
        return token_type;
    }

    public String getExpires_in() {
        return expires_in;
    }

    public String getScope() {
        return scope;
    }

    public String getSvc_tgt_seq() {
        return svc_tgt_seq;
    }

    public String getPlatform() {
        return platform;
    }

    public String getSvc_cd() {
        return svc_cd;
    }

    public String getMbr_seq() {
        return mbr_seq;
    }

    public String getCompany() {
        return company;
    }

    public String getDstr_cd() {
        return dstr_cd;
    }

    public String getTheme_cd() {
        return theme_cd;
    }

    public String getMbr_id() {
        return mbr_id;
    }

    public String getJti() {
        return jti;
    }
}

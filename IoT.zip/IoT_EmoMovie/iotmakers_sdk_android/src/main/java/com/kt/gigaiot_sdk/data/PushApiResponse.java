package com.kt.gigaiot_sdk.data;

import java.util.ArrayList;

/**
 * Created by ceoko on 15. 4. 10..
 */
public class PushApiResponse extends Response{


    public PushApiResponse(String responseCode, String message) {
        super(responseCode, message);
    }
}
